# README file generator


  ## Description
  This generator will help you to create README.md file for your project answering the questions.

  ### Table of Contents
- [Installation](#installation)
- [Usage](#usage)
- [License](#license)
- [Contributing](#contributing)
- [Tests](#tests)
- [Questions](#questions)

## Installation
Pull code from GitHub repo.

## Usage
Open command prompt for using - node index.js and answer the questions.

## License
Apache License 2.0

### Contributing
Have used all materials of week_11, Google searcg and tips of TA.

## Tests
You can test it using command - node index.js and then find new file in a foulder

## Questions
If you have any questions, please, write [tata19.qmail](mailto:tata19.qmail)
GitHub : [https://github.com/](https://github.com/) 
